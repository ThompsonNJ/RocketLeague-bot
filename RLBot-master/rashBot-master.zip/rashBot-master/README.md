# rashBot

A Rocket league bot for RLBot


### RLBot

RLBot is a framework to create bots to play rocket league that reads values from the game and outputs button presses to the game.

https://github.com/drssoccer55/RLBot/
